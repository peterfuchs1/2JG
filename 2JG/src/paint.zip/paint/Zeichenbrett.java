package paint;
/**
 * Startklasse des Zeichenbretts
 * @author Walter Rafeiner-Magor
 * @version 3.0
 */
public class Zeichenbrett {
	public static void main(String[] args) {
		new MyController();
	}

}
